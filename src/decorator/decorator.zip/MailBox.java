package decorator;

public interface MailBox {

    void wyswietl();
    void setContent(String content);
    String getContent();

}
